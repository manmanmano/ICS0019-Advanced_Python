# Triangle area
This module can be used to import a function that will calculate the area
of a triangle based on the user input. The expected input consists of 
base (b) and height (a).
